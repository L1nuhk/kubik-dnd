plugins { id("com.android.application") }

android {
    namespace = "ru.kubik.dnd"
    compileSdk = 35

    defaultConfig {
        applicationId = "ru.kubik.dnd"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
